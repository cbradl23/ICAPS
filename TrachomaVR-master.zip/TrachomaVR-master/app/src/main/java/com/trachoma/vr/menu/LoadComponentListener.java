package com.trachoma.vr.menu;

/**
 * Created by anton.bevza on 20.02.2018.
 */

interface LoadComponentListener {
    void onFinishLoadComponent();
}
