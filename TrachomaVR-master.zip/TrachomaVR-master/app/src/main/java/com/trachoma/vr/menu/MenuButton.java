package com.trachoma.vr.menu;
/*
 * Created by Anton Bevza on 1/16/18.
 */

import android.graphics.Color;
import android.view.Gravity;

import com.trachoma.vr.R;
import com.trachoma.vr.focus.FocusListener;
import com.trachoma.vr.focus.FocusableSceneObject;

import org.gearvrf.GVRAndroidResource;
import org.gearvrf.GVRContext;
import org.gearvrf.GVRDrawFrameListener;
import org.gearvrf.GVRMaterial;
import org.gearvrf.GVRMesh;
import org.gearvrf.GVRMeshCollider;
import org.gearvrf.GVRRenderData;
import org.gearvrf.GVRSceneObject;
import org.gearvrf.GVRTexture;
import org.gearvrf.scene_objects.GVRTextViewSceneObject;

public class MenuButton extends FocusableSceneObject implements FocusListener {

    private float itemWidth = 0.5f;
    private float itemHeight = 0.5f;
    private GVRSceneObject loadComponent = null;
    private final GVRTextViewSceneObject textObject;
    private LoadComponentListener listener;
    private GVRDrawFrameListener drawFrameListener;
    private float valueFloatTexture;
    private static final float LOADING_SPEED = 0.025f;

    public MenuButton(GVRContext gvrContext, String text, float itemWidth) {
        super(gvrContext);
        this.itemWidth = itemWidth;
        attachRenderData(new GVRRenderData(gvrContext));
        getRenderData().setMaterial(new GVRMaterial(gvrContext));
        getRenderData().setMesh(gvrContext.createQuad(itemWidth, itemHeight));
        GVRTexture texture = gvrContext.getAssetLoader().loadTexture(new GVRAndroidResource(gvrContext, R.drawable.white));
        getRenderData().getMaterial().setMainTexture(texture);
        getRenderData().getMaterial().setColor(Color.GRAY);

        textObject = new GVRTextViewSceneObject(gvrContext, itemWidth, itemHeight, text);
        textObject.getTransform().setPosition(0, 0, .02f);
        textObject.setTextSize(6);
        textObject.setGravity(Gravity.CENTER);

        this.addChildObject(textObject);
        this.attachCollider(new GVRMeshCollider(getGVRContext(), false));
        this.focusListener = this;
    }

    public MenuButton(GVRContext gvrContext, String text) {
        this(gvrContext, text, 1f);
    }

    @Override
    public void gainedFocus(FocusableSceneObject object) {
        createLoadComponent();
    }

    @Override
    public void lostFocus(FocusableSceneObject object) {
        if (this.loadComponent != null) {
            stopLoading();
        }
    }

    @Override
    public void inFocus(FocusableSceneObject object) {

    }

    private void createLoadComponent() {
        GVRMesh quad = getGVRContext().createQuad(itemWidth, itemHeight);
        GVRTexture texture = getGVRContext().getAssetLoader().loadTexture(new GVRAndroidResource(getGVRContext(), R.drawable.white));
        loadComponent = new GVRSceneObject(getGVRContext(), quad, texture);
        loadComponent.getRenderData().getMaterial().setColor(Color.GREEN);
        loadComponent.getTransform().setPosition(0, 0, 0.01f);
        loadComponent.getTransform().setScale(0, 1, 1);

        drawFrameListener = new GVRDrawFrameListener() {

            @Override
            public void onDrawFrame(float frameTime) {
                valueFloatTexture += LOADING_SPEED;

                if (valueFloatTexture <= 1) {
                    loadComponent.getTransform().setScale(valueFloatTexture, 1, 1);

                } else {
                    stopLoading();
                    listener.onFinishLoadComponent();
                }

            }
        };

        getGVRContext().registerDrawFrameListener(drawFrameListener);
        addChildObject(loadComponent);
    }

    private void stopLoading() {
        getGVRContext().unregisterDrawFrameListener(drawFrameListener);
        valueFloatTexture = 0.0f;
        removeChildObject(loadComponent);
    }

    public void setListener(LoadComponentListener listener) {
        this.listener = listener;
    }
}
