package com.trachoma.vr.focus;

import org.gearvrf.GVRPicker;
import org.gearvrf.GVRSceneObject;
import org.gearvrf.IPickEvents;

public class PickHandler implements IPickEvents
{
    public GVRSceneObject PickedObject = null;

    public void onEnter(GVRSceneObject sceneObj, GVRPicker.GVRPickedObject pickInfo)
    {
        if (sceneObj instanceof FocusableSceneObject)
        {
            FocusableSceneObject fo = (FocusableSceneObject) sceneObj;
            PickedObject = fo;
            fo.setFocus(true);
            fo.dispatchInFocus();
            fo.hitLocation = pickInfo.getHitLocation();
        }
    }

    public void onInside(GVRSceneObject sceneObj, GVRPicker.GVRPickedObject pickInfo) {
        FocusableController.process(sceneObj);
    }
    public void onPick(GVRPicker picker) { }

    public void onExit(GVRSceneObject sceneObj)
    {
        FocusableSceneObject fo = (FocusableSceneObject) PickedObject;
        if (fo != null)
        {
            fo.setFocus(false);
        }
    }
    public void onNoPick(GVRPicker picker)
    {
        FocusableSceneObject fo = (FocusableSceneObject) PickedObject;
        if (fo != null)
        {
            fo.setFocus(false);
        }
        PickedObject = null;
        GazeController.disableInteractiveCursor();
    }


}