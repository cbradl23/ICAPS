/* Copyright 2015 Samsung Electronics Co., LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.trachoma.vr.focus;

import com.trachoma.vr.input.TouchPadInput;
import com.trachoma.vr.util.VRTouchPadGestureDetector;

import org.gearvrf.GVRContext;
import org.gearvrf.GVRMesh;
import org.gearvrf.GVRSceneObject;
import org.gearvrf.GVRTexture;

public class FocusableSceneObject extends GVRSceneObject {

    private boolean focus = false;
    public FocusListener focusListener = null;
    public String tag = null;
    public boolean showInteractiveCursor = true;
    private OnClickListener onClickListener;
    private OnGestureListener onGestureListener;
    public float[] hitLocation;

    public FocusableSceneObject(GVRContext gvrContext) {
        super(gvrContext);
    }

    public FocusableSceneObject(GVRContext gvrContext, GVRMesh gvrMesh, GVRTexture gvrTexture) {
        super(gvrContext, gvrMesh, gvrTexture);
    }

    public FocusableSceneObject(GVRContext gvrContext, float width, float height, GVRTexture t) {
        super(gvrContext, width, height, t);
    }

    public void dispatchGainedFocus() {
        if (this.focusListener != null) {
            this.focusListener.gainedFocus(this);
        }
        if (showInteractiveCursor) {
            GazeController.enableInteractiveCursor();
        }
    }

    public void dispatchLostFocus() {
        if (this.focusListener != null) {
            focusListener.lostFocus(this);
        }
        if (showInteractiveCursor) {
            GazeController.disableInteractiveCursor();
        }
    }

    public void setFocus(boolean state) {
        if (state && !focus) {
            focus = true;
            this.dispatchGainedFocus();
            return;
        }

        if (!state && focus) {
            focus = false;
            this.dispatchLostFocus();
        }
    }

    public void dispatchInFocus() {
        if (this.focusListener != null) {
            this.focusListener.inFocus(this);
        }
        if (showInteractiveCursor) {
            GazeController.enableInteractiveCursor();
        }
    }

    public void dispatchInClick() {
        if (this.onClickListener != null)
            this.onClickListener.onClick();
    }

    public boolean hasFocus() {
        return focus;
    }

    public void setOnClickListener(OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public void setOnGestureListener(OnGestureListener onGestureListener) {
        this.onGestureListener = onGestureListener;
    }

    public boolean isFocus() {
        return focus;
    }

    public void dispatchInGesture(VRTouchPadGestureDetector.SwipeDirection swipeDirection) {
        if (this.onGestureListener != null) {

            if (TouchPadInput.getCurrent().swipeDirection == VRTouchPadGestureDetector.SwipeDirection.Ignore)
                onGestureListener.onSwipeIgnore();
            else if (TouchPadInput.getCurrent().swipeDirection == VRTouchPadGestureDetector.SwipeDirection.Forward)
                onGestureListener.onSwipeForward();
            else if (TouchPadInput.getCurrent().swipeDirection == VRTouchPadGestureDetector.SwipeDirection.Backward)
                onGestureListener.onSwipeBack();
            else if (TouchPadInput.getCurrent().swipeDirection == VRTouchPadGestureDetector.SwipeDirection.Up)
                onGestureListener.onSwipeUp();
            else
                onGestureListener.onSwipeDown();

        }
    }
}
