/* Copyright 2015 Samsung Electronics Co., LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.trachoma.vr.focus;

import com.trachoma.vr.R;
import com.trachoma.vr.input.TouchPadInput;

import org.gearvrf.GVRAndroidResource;
import org.gearvrf.GVRContext;
import org.gearvrf.GVRSceneObject;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public final class FocusableController {

    public static CopyOnWriteArrayList<FocusableSceneObject> interactiveObjects = new CopyOnWriteArrayList<FocusableSceneObject>();

    public static void process(GVRSceneObject sceneObject) {

        ArrayList<FocusableSceneObject> needToDisableFocus = new ArrayList<FocusableSceneObject>();

        for (FocusableSceneObject obj : interactiveObjects) {
            needToDisableFocus.add(obj);
        }

        if (sceneObject == null) {
            GazeController.disableInteractiveCursor();
        } else {
            FocusableSceneObject object = (FocusableSceneObject) sceneObject;
            object.setFocus(true);
            object.dispatchInFocus();
            needToDisableFocus.remove(object);
        }

        for (FocusableSceneObject obj : needToDisableFocus) {
            obj.setFocus(false);
        }

    }

    public static boolean swipeProcess(GVRContext context, PickHandler mPickHandler) {
        if (mPickHandler == null) {
            return false;
        }
        if (mPickHandler.PickedObject != null &&
                isAVisibleObjectBeingSeen(context, mPickHandler.PickedObject)) {
            FocusableSceneObject object = (FocusableSceneObject) mPickHandler.PickedObject;
            object.dispatchInGesture(TouchPadInput.getCurrent().swipeDirection);
            return true;
        }
        return false;
    }

    public static boolean clickProcess(GVRContext context, PickHandler mPickHandler) {
        if (mPickHandler == null) {
            return false;
        } else {
            FocusableSceneObject object = (FocusableSceneObject) mPickHandler.PickedObject;
            object.dispatchInClick();
            return true;
        }
    }

    private static boolean isAVisibleObjectBeingSeen(GVRContext gvrContext, GVRSceneObject object) {
        return (isVisible(object) && !hasEmptyTexture(gvrContext, object));
    }

    private static boolean isVisible(GVRSceneObject object) {
        return object.getRenderData() != null && object.getRenderData().getMaterial() != null
                && object.getRenderData().getMaterial().getOpacity() > 0;
    }

    private static boolean hasEmptyTexture(GVRContext gvrContext, GVRSceneObject object) {
        return object.getRenderData().getMaterial().getMainTexture() != null
                && object.getRenderData().getMaterial().getMainTexture()
                .equals(gvrContext.getAssetLoader().loadTexture(new GVRAndroidResource(gvrContext, R.drawable.empty_clickable)));
    }

}
