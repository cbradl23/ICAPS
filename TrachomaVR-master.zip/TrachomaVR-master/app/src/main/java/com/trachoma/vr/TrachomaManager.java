package com.trachoma.vr;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.util.Size;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Surface;

import com.trachoma.vr.focus.GazeController;
import com.trachoma.vr.focus.PickHandler;
import com.trachoma.vr.menu.ConfirmationDialog;
import com.trachoma.vr.menu.MainMenu;
import com.trachoma.vr.menu.PreviewPhotoDialog;
import com.trachoma.vr.storage.ScannedBarCodesStorage;
import com.trachoma.vr.util.AppUtils;
import com.trachoma.vr.util.CapturePhotoUtils;

import org.gearvrf.GVRAndroidResource;
import org.gearvrf.GVRContext;
import org.gearvrf.GVRDrawFrameListener;
import org.gearvrf.GVRExternalTexture;
import org.gearvrf.GVRMain;
import org.gearvrf.GVRMaterial.GVRShaderType;
import org.gearvrf.GVRMesh;
import org.gearvrf.GVRPicker;
import org.gearvrf.GVRRenderData;
import org.gearvrf.GVRScene;
import org.gearvrf.GVRSceneObject;
import org.gearvrf.GVRTexture;
import org.gearvrf.IPickEvents;
import org.gearvrf.animation.GVROpacityAnimation;
import org.gearvrf.animation.GVRRepeatMode;
import org.gearvrf.io.GVRControllerType;
import org.gearvrf.io.GVRCursorController;
import org.gearvrf.io.GVRGearCursorController;
import org.gearvrf.io.GVRInputManager;
import org.gearvrf.scene_objects.GVRTextViewSceneObject;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class TrachomaManager extends GVRMain {
    private static final float zoomedAreaProportion = 0.2f;

    private TrachomaActivity activity;
    private SurfaceTexture surfaceTexture;
    private SurfaceTexture surfaceZoomedTexture;
    private CameraHelper cameraHelper;
    private List<Surface> surfaces;
    private GVRSceneObject zoomedObject;
    private IPickEvents pickHandler = new PickHandler();
    private GVRTextViewSceneObject screenTitleObject;
    private MainMenu mainMenu;

    private String patientId;
    private Boolean isLeftEye;

    private GVRSceneObject barCodeSectorObject;
    private ConfirmationDialog confirmationDialog;
    private ConfirmationDialog pickUpEyeDialog;
    private ConfirmationDialog nextPhotoDialog;
    private PreviewPhotoDialog previewPhotoDialog;
    private GVRSceneObject batteryLowObject;
    private GVROpacityAnimation batteryIconAnimation;
    private int batteryLevel = 100;
    private GVRGearCursorController gearController;

    private CameraHelper.CameraListener cameraListener = new CameraHelper.CameraListener() {
        @Override
        public void onQrCodeRead(String text) {
            AppUtils.showToast(getGVRContext(), text, 2f);
            cameraHelper.setCameraState(CameraHelper.CameraState.PREVIEW);
            showBarcodeConfirmationDialog(text);
        }

        @Override
        public void onPhotoCaptured(Bitmap capturedPhoto) {
            showJustPreview();
            showPhotoPreviewDialog(capturedPhoto);
        }
    };

    public TrachomaManager(TrachomaActivity activity) {
        this.activity = activity;
    }

    @Override
    public SplashMode getSplashMode() {
        return SplashMode.AUTOMATIC;
    }

    @Override
    public void onInit(final GVRContext gvrContext) throws Throwable {
        final GVRScene mainScene = gvrContext.getMainScene();
        mainScene.getEventReceiver().addListener(pickHandler);

        GVRPicker picker = new GVRPicker(gvrContext, mainScene);
        mainScene.getMainCameraRig().getHeadTransformObject().attachComponent(picker);

        final GVRExternalTexture passThroughTexture = new GVRExternalTexture(gvrContext);
        surfaceTexture = new SurfaceTexture(passThroughTexture.getId());

        GVRSceneObject passThroughObject = new GVRSceneObject(gvrContext, gvrContext.createQuad(16, 9), passThroughTexture,
                GVRShaderType.OES.ID);
        passThroughObject.getTransform().setPositionY(-0.2f);
        passThroughObject.getTransform().setPositionZ(-12.0f);
        mainScene.getMainCameraRig().addChildObject(passThroughObject);

        GVRExternalTexture zoomedTexture = new GVRExternalTexture(gvrContext);
        surfaceZoomedTexture = new SurfaceTexture(zoomedTexture.getId());

        zoomedObject = new GVRSceneObject(gvrContext, gvrContext.createQuad(4, 2.25f), zoomedTexture,
                GVRShaderType.OES.ID);
        zoomedObject.getTransform().setPositionY(-0f);
        zoomedObject.getTransform().setPositionX(0f);
        zoomedObject.getTransform().setPositionZ(-11.99f);

        GVRRenderData renderData = zoomedObject.getRenderData();

        float x1 = 0.5f - zoomedAreaProportion / 2;
        float y1 = 1 - x1;

        float[] texCoords = {x1, x1, x1, y1, y1, x1, y1, y1};
        GVRMesh mesh = renderData.getMesh();
        mesh.setTexCoords(texCoords);
        renderData.setMesh(mesh);

        mainScene.getMainCameraRig().addChildObject(zoomedObject);

        gvrContext.registerDrawFrameListener(new GVRDrawFrameListener() {
            @Override
            public void onDrawFrame(float v) {
                surfaceTexture.updateTexImage();
                surfaceZoomedTexture.updateTexImage();
            }
        });

        cameraHelper = new CameraHelper(activity, gvrContext, 0, cameraListener);
        Size previewSize = cameraHelper.setPreferredSize(1920, 1080, zoomedAreaProportion);

        surfaceTexture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
        Surface surface = new Surface(surfaceTexture);

        surfaceZoomedTexture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
        Surface zoomedSurface = new Surface(surfaceZoomedTexture);

        Surface[] surface_array = {surface, zoomedSurface};
        surfaces = Arrays.asList(surface_array);

        if (activity.checkPermissions()) {
            cameraHelper.startCapture(surfaces);
        } else {
            activity.requestPermissions();
        }

        GazeController.setupGazeCursor(gvrContext);

        zoomedObject.setEnable(false);
        getGVRContext().runOnGlThreadPostRender(64, new Runnable() {
            @Override
            public void run() {
                GazeController.enableGaze();
            }
        });

        showMainMenu();
        updateBatteryIcon();

        setupController(gvrContext);
    }

    public void onPause() {
        if (cameraHelper != null) {
            cameraHelper.closeCamera();
        }
    }


    public void onResume() {
        try {
            if (cameraHelper != null) {
                cameraHelper.startCapture(surfaces);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }


    public void permissionsGranted() {
    }

    public void onSingleTap() {
        if (gearController == null) {
            if (cameraHelper != null) {
                cameraHelper.takePicture();
            }
        }
    }

    public void onVolumeUpBtnPressed() {
        if (cameraHelper != null) {
            cameraHelper.focusUp();
        }
    }

    public void onVolumeDownBtnPressed() {
        if (cameraHelper != null) {
            cameraHelper.focusDown();
        }
    }

    public void onBatteryLevelChanged(int level) {
        batteryLevel = level;
        updateBatteryIcon();
    }

    @Override
    public boolean onBackPress() {
        return returnToStart();
    }

    private void setupController(GVRContext gvrContext) {
        GVRInputManager input = gvrContext.getInputManager();
        input.selectController(new GVRInputManager.ICursorControllerSelectListener() {
            @Override
            public void onCursorControllerSelected(GVRCursorController newController, GVRCursorController oldController) {
                if (newController.getControllerType() == GVRControllerType.CONTROLLER) {
                    gearController = (GVRGearCursorController) newController;
                    gearController.addControllerEventListener(new GVRCursorController.IControllerEvent() {
                        @Override
                        public void onEvent(GVRCursorController controller, boolean isActive) {
                            gearController.showControllerModel(false);
                            KeyEvent keyEvent = controller.getKeyEvent();
                            if (keyEvent != null) {
                                if (keyEvent.getAction() != GVRGearCursorController.CONTROLLER_KEYS.BUTTON_HOME.getNumVal() &&
                                        keyEvent.getAction() != GVRGearCursorController.CONTROLLER_KEYS.BUTTON_VOLUME_DOWN.getNumVal() &&
                                        keyEvent.getAction() != GVRGearCursorController.CONTROLLER_KEYS.BUTTON_VOLUME_UP.getNumVal() &&
                                        keyEvent.getAction() != GVRGearCursorController.CONTROLLER_KEYS.BUTTON_BACK.getNumVal()) {
                                    if (cameraHelper != null) {
                                        cameraHelper.takePicture();
                                    }
                                }
                            }
                        }
                    });
                } else {
                    newController.setEnable(false);
                    gearController = null;
                }
            }
        });
    }

    private boolean returnToStart() {
        if (confirmationDialog != null) {
            confirmationDialog.setEnable(false);
            getGVRContext().getMainScene().removeSceneObject(confirmationDialog);
        }
        if (pickUpEyeDialog != null) {
            pickUpEyeDialog.setEnable(false);
            getGVRContext().getMainScene().removeSceneObject(pickUpEyeDialog);
        }
        if (nextPhotoDialog != null) {
            nextPhotoDialog.setEnable(false);
            getGVRContext().getMainScene().removeSceneObject(nextPhotoDialog);
        }
        if (previewPhotoDialog != null) {
            previewPhotoDialog.setEnable(false);
            getGVRContext().getMainScene().removeSceneObject(previewPhotoDialog);
        }
        showJustPreview();
        showMainMenu();
        return true;
    }

    private void showMainMenu() {
        resetStartingPoint();
        if (mainMenu == null) {
            mainMenu = new MainMenu(getGVRContext());
            mainMenu.getTransform().setPosition(0, -0.2f, -5f);
            mainMenu.setListener(new MainMenu.Listener() {
                @Override
                public void onScanBarcodeSelected() {
                    showQrDecoding();
                    mainMenu.setEnable(false);
                }
            });
            getGVRContext().getMainScene().addSceneObject(mainMenu);
        }

        mainMenu.setEnable(true);

        setScreenTitle(activity.getString(R.string.screen_title_main_menu));
    }

    private void showBarcodeConfirmationDialog(final String text) {
        resetStartingPoint();
        getGVRContext().runOnGlThreadPostRender(64, new Runnable() {
            @Override
            public void run() {
                GazeController.enableGaze();
            }
        });
        zoomedObject.setEnable(false);
        barCodeSectorObject.setEnable(false);
        String title;
        if (ScannedBarCodesStorage.getInstance(getGVRContext().getContext()).isCodeScanned(text)) {
            title = activity.getString(R.string.barcode_scanned_before, text);
        } else {
            title = activity.getString(R.string.screen_title_patient, text);
        }
        confirmationDialog = new ConfirmationDialog(getGVRContext(), title);
        confirmationDialog.getTransform().setPosition(0, 0, -5f);
        confirmationDialog.setListener(new ConfirmationDialog.Listener() {

            @Override
            public void onPositiveButtonClicked() {
                ScannedBarCodesStorage.getInstance(getGVRContext().getContext()).addScannedCode(text);
                confirmationDialog.setEnable(false);
                patientId = text;
                setScreenTitle(text);
                showPickUpEyeDialog();
            }

            @Override
            public void onNegativeButtonClicked() {
                confirmationDialog.setEnable(false);
                getGVRContext().getMainScene().removeSceneObject(confirmationDialog);
                showQrDecoding();
            }

            @Override
            public void onNeutralButtonClicked() {
            }

            @Override
            public void onCancelButtonClicked() {
                returnToStart();
            }
        });
        getGVRContext().getMainScene().addSceneObject(confirmationDialog);
    }

    private void showPickUpEyeDialog() {
        if (pickUpEyeDialog == null) {
            pickUpEyeDialog = new ConfirmationDialog(getGVRContext(),
                    activity.getString(R.string.pick_up_eye_title),
                    activity.getString(R.string.right), activity.getString(R.string.left));
            pickUpEyeDialog.getTransform().setPosition(0, -0.5f, -5f);
            pickUpEyeDialog.setListener(new ConfirmationDialog.Listener() {

                @Override
                public void onPositiveButtonClicked() {
                    isLeftEye = false;
                    setScreenTitle(patientId + " " + getEyeString());
                    showPhotoPreview();
                    pickUpEyeDialog.setEnable(false);
                    getGVRContext().getMainScene().removeSceneObject(pickUpEyeDialog);
                }

                @Override
                public void onNegativeButtonClicked() {
                    isLeftEye = true;
                    setScreenTitle(patientId + " " + getEyeString());
                    showPhotoPreview();
                    pickUpEyeDialog.setEnable(false);
                    getGVRContext().getMainScene().removeSceneObject(pickUpEyeDialog);
                }

                @Override
                public void onNeutralButtonClicked() {
                }

                @Override
                public void onCancelButtonClicked() {
                    returnToStart();
                }
            });
        }
        pickUpEyeDialog.setEnable(true);
        getGVRContext().getMainScene().addSceneObject(pickUpEyeDialog);
    }

    private void showPhotoPreviewDialog(final Bitmap capturedPhoto) {
        resetStartingPoint();
        previewPhotoDialog = new PreviewPhotoDialog(getGVRContext(), capturedPhoto);
        previewPhotoDialog.getTransform().setPosition(0, 0, -5f);
        previewPhotoDialog.setListener(new PreviewPhotoDialog.Listener() {
            @Override
            public void onPositiveButtonClicked() {
                String filePath = savePhoto(capturedPhoto);
                previewPhotoDialog.setEnable(false);
                getGVRContext().getMainScene().removeSceneObject(previewPhotoDialog);
                showNextPhotoDialog(filePath);
            }

            @Override
            public void onNegativeButtonClicked() {
                previewPhotoDialog.setEnable(false);
                getGVRContext().getMainScene().removeSceneObject(previewPhotoDialog);
                showNextPhotoDialog(null);
            }

            @Override
            public void onCancelButtonClicked() {
                returnToStart();
            }
        });
        getGVRContext().getMainScene().addSceneObject(previewPhotoDialog);
    }

    private void showNextPhotoDialog(String fileName) {
        String title;

        setScreenTitle(patientId);

        if (fileName != null) {
            title = activity.getString(R.string.photo_saved, fileName);
        } else {
            title = activity.getString(R.string.photo_deleted);
        }
        nextPhotoDialog = new ConfirmationDialog(getGVRContext(), title, activity.getString(R.string.new_patient),
                activity.getString(R.string.right_eye), activity.getString(R.string.left_eye));
        nextPhotoDialog.getTransform().setPosition(0, 0, -5);
        nextPhotoDialog.setListener(new ConfirmationDialog.Listener() {

            @Override
            public void onPositiveButtonClicked() {
                getGVRContext().getMainScene().removeSceneObject(nextPhotoDialog);
                nextPhotoDialog.setEnable(false);
                showQrDecoding();
            }

            @Override
            public void onNegativeButtonClicked() {
                isLeftEye = false;
                setScreenTitle(patientId + " " + getEyeString());
                getGVRContext().getMainScene().removeSceneObject(nextPhotoDialog);
                nextPhotoDialog.setEnable(false);
                showPhotoPreview();
            }

            @Override
            public void onNeutralButtonClicked() {
                isLeftEye = true;
                setScreenTitle(patientId + " " + getEyeString());
                getGVRContext().getMainScene().removeSceneObject(nextPhotoDialog);
                nextPhotoDialog.setEnable(false);
                showPhotoPreview();
            }

            @Override
            public void onCancelButtonClicked() {
                returnToStart();
            }
        });
        nextPhotoDialog.setEnable(true);
        getGVRContext().getMainScene().addSceneObject(nextPhotoDialog);
    }

    private void showQrDecoding() {
        GazeController.disableGaze();
        zoomedObject.setEnable(false);
        cameraHelper.setCameraState(CameraHelper.CameraState.QR_DECODING);
        setScreenTitle(activity.getString(R.string.screen_title_scanning_barcode));

        if (barCodeSectorObject == null) {
            createBarCodeSectorObject();
        }
        barCodeSectorObject.setEnable(true);
    }

    private void showPhotoPreview() {
        getGVRContext().runOnGlThreadPostRender(64, new Runnable() {
            @Override
            public void run() {
                zoomedObject.setEnable(true);
                barCodeSectorObject.setEnable(false);
                cameraHelper.setCameraState(CameraHelper.CameraState.PHOTO);
                GazeController.disableGaze();
            }
        });
    }

    private void showJustPreview() {
        getGVRContext().runOnGlThreadPostRender(64, new Runnable() {
            @Override
            public void run() {
                if (zoomedObject != null) {
                    zoomedObject.setEnable(false);
                }
                if (barCodeSectorObject != null) {
                    barCodeSectorObject.setEnable(false);
                }
                cameraHelper.setCameraState(CameraHelper.CameraState.PREVIEW);
                GazeController.enableGaze();
            }
        });
    }

    private void createBarCodeSectorObject() {
        GVRMesh quad = getGVRContext().createQuad(2.66f, 1.5f);
        GVRTexture texture = getGVRContext().getAssetLoader().loadTexture(
                new GVRAndroidResource(getGVRContext(), R.drawable.sector));
        barCodeSectorObject = new GVRSceneObject(getGVRContext(), quad, texture);
        barCodeSectorObject.getRenderData().getMaterial().setColor(Color.GREEN);
        barCodeSectorObject.getTransform().setPosition(0, 0, -11.99f);

        getGVRContext().getMainScene().getMainCameraRig().addChildObject(barCodeSectorObject);
    }

    private void showBatteryLowIcon() {
        if (batteryLowObject == null && getGVRContext() != null) {
            GVRMesh quad = getGVRContext().createQuad(0.1f, 0.1f);
            GVRTexture texture = getGVRContext().getAssetLoader().loadTexture(
                    new GVRAndroidResource(getGVRContext(), R.drawable.low_battery));
            batteryLowObject = new GVRSceneObject(getGVRContext(), quad, texture);
            batteryLowObject.getTransform().setPosition(0.4f, 0.3f, -1f);
            getGVRContext().getMainScene().getMainCameraRig().addChildObject(batteryLowObject);

            batteryIconAnimation = new GVROpacityAnimation(batteryLowObject, 1f, 0);
            batteryIconAnimation.setRepeatMode(GVRRepeatMode.PINGPONG);
            batteryIconAnimation.setRepeatCount(-1);
            batteryIconAnimation.start(getGVRContext().getAnimationEngine());
        }
    }

    private void hideBatteryLowIcon() {
        if (batteryLowObject != null) {
            getGVRContext().getMainScene().getMainCameraRig().removeChildObject(batteryLowObject);
            getGVRContext().getAnimationEngine().stop(batteryIconAnimation);

            batteryLowObject = null;
            batteryIconAnimation = null;
        }
    }

    private void updateBatteryIcon() {
        if (batteryLevel <= 10) {
            showBatteryLowIcon();
        } else {
            hideBatteryLowIcon();
        }
    }

    private void setScreenTitle(String title) {
        if (screenTitleObject == null) {
            screenTitleObject = new GVRTextViewSceneObject(getGVRContext(), 1.2f, 0.2f, title);
            screenTitleObject.getTransform().setPosition(0, -0.6f, -2f);
            screenTitleObject.setTextSize(4);
            screenTitleObject.setGravity(Gravity.CENTER);
            screenTitleObject.setBackgroundColor(Color.BLACK);

            getGVRContext().getMainScene().getMainCameraRig().addChildObject(screenTitleObject);
        } else {
            screenTitleObject.setText(title);
        }
    }

    private String getEyeString() {
        return isLeftEye ? activity.getString(R.string.left_eye).toLowerCase() : activity.getString(R.string.right_eye).toLowerCase();
    }

    private String savePhoto(Bitmap capturedPhoto) {
        Date d = new Date();
        CharSequence dateString = android.text.format.DateFormat.format("MMddyy", d.getTime());
        CharSequence timeString = android.text.format.DateFormat.format("hhmmss", d.getTime());
        String eyeName = isLeftEye ? "L" : "R";
        String fileName = patientId + "_" + dateString + "_" + timeString + "_" + eyeName;
        return CapturePhotoUtils.insertImage(activity, capturedPhoto, fileName);
    }

    private void resetStartingPoint() {
        getGVRContext().getMainScene().getMainCameraRig().resetYaw();
    }
}
