package com.trachoma.vr.storage;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by anton.bevza on 23.03.2018.
 */

public class ScannedBarCodesStorage {
    private static final String PREFS_NAME = "scanner_storage";
    private static final String KEY_SCANNED_CODES = "scanned_codes";

    private static ScannedBarCodesStorage instance;

    private Set<String> scannedCodes;
    private SharedPreferences sharedPreferences;

    public static ScannedBarCodesStorage getInstance(Context context) {
        if (instance == null) {
            instance = new ScannedBarCodesStorage();
            instance.init(context);
        }
        return instance;
    }

    private void init(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        scannedCodes = sharedPreferences.getStringSet(KEY_SCANNED_CODES, null);
    }

    public boolean isCodeScanned(String code) {
        return scannedCodes != null && scannedCodes.contains(code);
    }

    public void addScannedCode(String code) {
        if (scannedCodes == null) {
            scannedCodes = new HashSet<>();
        }

        scannedCodes.add(code);
        sharedPreferences.edit().putStringSet(KEY_SCANNED_CODES, scannedCodes).apply();
    }


}
