package com.trachoma.vr.menu;
/*
 * Created by Anton Bevza on 1/18/18.
 */

import android.graphics.Color;
import android.view.Gravity;

import com.trachoma.vr.R;

import org.gearvrf.GVRAndroidResource;
import org.gearvrf.GVRContext;
import org.gearvrf.GVRMaterial;
import org.gearvrf.GVRRenderData;
import org.gearvrf.GVRSceneObject;
import org.gearvrf.GVRTexture;
import org.gearvrf.scene_objects.GVRTextViewSceneObject;

public class ConfirmationDialog extends GVRSceneObject {
    private Listener listener;

    public ConfirmationDialog(GVRContext gvrContext, String text, String positiveButtonText, String negativeButtonText, String neutralButtonText) {
        super(gvrContext);

        GVRTextViewSceneObject textObject = new GVRTextViewSceneObject(gvrContext, 2, 1, text);
        textObject.setTextSize(6);
        textObject.setGravity(Gravity.CENTER);
        textObject.setTextColor(Color.BLACK);
        textObject.getTransform().setPosition(0, 0.5f, 0.01f);

        addChildObject(textObject);

        attachRenderData(new GVRRenderData(gvrContext));
        getRenderData().setMaterial(new GVRMaterial(gvrContext));
        int width = neutralButtonText == null ? 3 : 4;
        int heigth = 2;
        getRenderData().setMesh(gvrContext.createQuad(width, heigth));
        GVRTexture texture = gvrContext.getAssetLoader().loadTexture(new GVRAndroidResource(gvrContext, R.drawable.white));
        getRenderData().getMaterial().setMainTexture(texture);
        getRenderData().getMaterial().setColor(Color.WHITE);
        String positiveText = positiveButtonText == null ? getGVRContext().getActivity().getString(R.string.yes) : positiveButtonText;
        final MenuButton yesButton = new MenuButton(getGVRContext(), positiveText);
        yesButton.getTransform().setPosition(-0.75f, -0.5f, 0.01f);
        yesButton.setListener(new LoadComponentListener() {
            @Override
            public void onFinishLoadComponent() {
                if (listener != null) {
                    listener.onPositiveButtonClicked();
                }
            }
        });

        addChildObject(yesButton);

        String negativeText = negativeButtonText == null ? getGVRContext().getActivity().getString(R.string.no) : negativeButtonText;
        final MenuButton noButton = new MenuButton(getGVRContext(), negativeText);
        noButton.getTransform().setPosition(0.75f, -0.5f, 0.01f);
        noButton.setListener(new LoadComponentListener() {
            @Override
            public void onFinishLoadComponent() {
                if (listener != null) {
                    listener.onNegativeButtonClicked();
                }
            }
        });

        addChildObject(noButton);

        if (neutralButtonText != null) {
            final MenuButton neutralButton = new MenuButton(getGVRContext(), neutralButtonText);
            neutralButton.getTransform().setPosition(1.25f, -0.5f, 0.01f);
            neutralButton.setListener(new LoadComponentListener() {
                @Override
                public void onFinishLoadComponent() {
                    if (listener != null) {
                        listener.onNeutralButtonClicked();
                    }
                }
            });

            addChildObject(neutralButton);

            yesButton.getTransform().setPosition(-1.25f, -0.5f, 0.01f);
            noButton.getTransform().setPosition(0f, -0.5f, 0.01f);
        }

        CancelButton cancelButton = new CancelButton(getGVRContext());
        cancelButton.getTransform().setPosition(width / 2f, heigth / 2f, 0.01f);
        cancelButton.setListener(new LoadComponentListener() {
            @Override
            public void onFinishLoadComponent() {
                if (listener != null) {
                    listener.onCancelButtonClicked();
                }
            }
        });
        addChildObject(cancelButton);
    }

    public ConfirmationDialog(GVRContext gvrContext, String text, String positiveButtonText, String negativeButtonText) {
        this(gvrContext, text, positiveButtonText, negativeButtonText, null);
    }

    public ConfirmationDialog(GVRContext gvrContext, String text) {
        this(gvrContext, text, null, null);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public interface Listener {
        void onPositiveButtonClicked();

        void onNegativeButtonClicked();

        void onNeutralButtonClicked();

        void onCancelButtonClicked();
    }


}
