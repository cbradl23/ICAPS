package com.trachoma.vr.util;
/*
 * Created by Anton Bevza on 1/9/18.
 */

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;

public class CapturePhotoUtils {

    public static String insertImage(Context context,
                                     Bitmap source,
                                     String title) {

        File storageDir = new File(Environment
                .getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/TrachomaVR/");
        if (!storageDir.exists())
            storageDir.mkdirs();
        File image = null;
        image = new File(storageDir, title + ".jpg");
        try {
            FileOutputStream out = new FileOutputStream(image);
            source.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (image != null) {
            addPicToGallery(context, image.getPath());
            return image.getName();
        } else {
            return null;
        }
    }

    public static void addPicToGallery(Context context, String photoPath) {
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        File f = new File(photoPath);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        context.sendBroadcast(mediaScanIntent);
    }

}
