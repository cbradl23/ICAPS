package com.trachoma.vr.util;
/*
 * Created by Anton Bevza on 1/10/18.
 */

import android.graphics.Color;
import android.view.Gravity;

import org.gearvrf.GVRCameraRig;
import org.gearvrf.GVRContext;
import org.gearvrf.GVRHybridObject;
import org.gearvrf.GVRMaterial;
import org.gearvrf.GVRRenderData;
import org.gearvrf.GVRTransform;
import org.gearvrf.animation.GVRAnimation;
import org.gearvrf.animation.GVRMaterialAnimation;
import org.gearvrf.animation.GVROnFinish;
import org.gearvrf.scene_objects.GVRTextViewSceneObject;

public class AppUtils {
    public static void showToast(final GVRContext context, final String message, float duration) {
        final float quadWidth = 1.2f;
        final GVRTextViewSceneObject toastSceneObject = new GVRTextViewSceneObject(context, quadWidth, quadWidth / 5,
                message);

        toastSceneObject.setTextSize(3);
        toastSceneObject.setTextColor(Color.WHITE);
        toastSceneObject.setGravity(Gravity.CENTER);
        toastSceneObject.setBackgroundColor(Color.DKGRAY);
        toastSceneObject.setRefreshFrequency(GVRTextViewSceneObject.IntervalFrequency.REALTIME);

        final GVRTransform t = toastSceneObject.getTransform();
        t.setPositionZ(-1.5f);
        t.setPositionY(-0.2f);

        final GVRRenderData rd = toastSceneObject.getRenderData();
        final float finalOpacity = 1f;
        rd.getMaterial().setOpacity(0);
        rd.setRenderingOrder(2 * GVRRenderData.GVRRenderingOrder.OVERLAY);
        rd.setDepthTest(false);

        final GVRCameraRig rig = context.getMainScene().getMainCameraRig();
        rig.addChildObject(toastSceneObject);

        final GVRMaterialAnimation fadeOut = new GVRMaterialAnimation(rd.getMaterial(), duration / 4.0f) {
            @Override
            protected void animate(GVRHybridObject target, float ratio) {
                final GVRMaterial material = (GVRMaterial) target;
                material.setOpacity(finalOpacity - ratio * finalOpacity);
            }
        };
        fadeOut.setOnFinish(new GVROnFinish() {
            @Override
            public void finished(GVRAnimation animation) {
                rig.removeChildObject(toastSceneObject);
            }
        });

        final GVRMaterialAnimation fadeIn = new GVRMaterialAnimation(rd.getMaterial(), 3.0f * duration / 4.0f) {
            @Override
            protected void animate(GVRHybridObject target, float ratio) {
                final GVRMaterial material = (GVRMaterial) target;
                material.setOpacity(ratio * finalOpacity);
            }
        };
        fadeIn.setOnFinish(new GVROnFinish() {
            @Override
            public void finished(GVRAnimation animation) {
                context.getAnimationEngine().start(fadeOut);
            }
        });

        context.getAnimationEngine().start(fadeIn);
    }
}
