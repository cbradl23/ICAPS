package com.trachoma.vr;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.MeteringRectangle;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Surface;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.Reader;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.oned.UPCAReader;
import com.trachoma.vr.util.AppUtils;
import com.trachoma.vr.util.PlanarYUVLuminanceSource;

import org.gearvrf.GVRContext;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import static android.hardware.camera2.CameraMetadata.CONTROL_AF_MODE_OFF;
import static android.hardware.camera2.CameraMetadata.CONTROL_AF_STATE_ACTIVE_SCAN;
import static android.hardware.camera2.CaptureRequest.CONTROL_AF_MODE;

public class CameraHelper {

    public enum CameraState {
        PREVIEW,
        QR_DECODING,
        PHOTO
    }

    private static final SparseIntArray ORIENTATIONS = new SparseIntArray();
    static {
        ORIENTATIONS.append(Surface.ROTATION_0, 90);
        ORIENTATIONS.append(Surface.ROTATION_90, 0);
        ORIENTATIONS.append(Surface.ROTATION_180, 270);
        ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }

    private static final String TAG = "CameraHelper";
    private static final int CAPTURE_PHOTO_WIDTH = 4032;
    private static final int CAPTURE_PHOTO_HEIGHT = 2268;
    private static final float INITIAL_FOCUS_DISTANCE = 0.525f;
    private static final float FOCUS_DISTANCE_FOR_SCANNING_BAR_CODE = 0.6f;
    private static final int IMAGE_FORMAT = ImageFormat.YUV_420_888;

    private Activity activity;
    private final GVRContext gvrContext;
    private Size[] availableSizes;
    private Size preferredSize;
    private Size zoomedSize;
    private CameraManager cameraManager;
    private String cameraId;
    private CameraDevice cameraDevice;
    private List<Surface> targetSurfaces;
    private CaptureRequest.Builder previewBuilder;
    private CameraCaptureSession previewSession;
    private CameraCharacteristics cameraCharacteristics;
    private float zoomedAreaProportion;
    private Handler backgroundHandler;
    private HandlerThread backgroundThread;
    private boolean canTakePhoto = false;
    private float focusDistance = INITIAL_FOCUS_DISTANCE;
    private CameraListener listener;
    private CameraState cameraState = CameraState.PREVIEW;

    //BARCODE DECODER
    private Reader mQrReader;
    private ImageReader mImageReader;
    private boolean readyToReadQr = true;
    private final int barCodeImageCroppedWidth = 672;
    private final int barCodeImageCroppedHeight = 378;
    private final int barCodeImageFullWidth = 4032;
    private final int barCodeImageFullHeight = 2268;

    private CameraCaptureSession.StateCallback mCaptureCallback = new CameraCaptureSession.StateCallback() {
        @Override
        public void onConfigured(CameraCaptureSession session) {
            previewSession = session;
            updatePreview();
            canTakePhoto = true;
        }

        @Override
        public void onConfigureFailed(CameraCaptureSession session) {

        }
    };

    private CameraDevice.StateCallback mStateCallback = new CameraDevice.StateCallback() {

        @Override
        public void onOpened(CameraDevice camera) {
            cameraDevice = camera;
            switch (cameraState) {
                case QR_DECODING:
                    startQrDecoding();
                    break;
                case PHOTO:
                    startPhotoPreview();
                    break;
                case PREVIEW:
                    startJustPreview();
                    break;
            }
        }

        @Override
        public void onDisconnected(CameraDevice camera) {
        }

        @Override
        public void onError(CameraDevice camera, int error) {
        }

    };

    CameraHelper(Activity activity, GVRContext gvrContext, int cameraIndex, CameraListener listener) throws CameraAccessException {
        this.activity = activity;
        this.listener = listener;
        this.gvrContext = gvrContext;
        targetSurfaces = new ArrayList<Surface>();

        cameraManager = (CameraManager) this.activity.getSystemService(Context.CAMERA_SERVICE);
        cameraId = cameraManager.getCameraIdList()[cameraIndex];
        cameraCharacteristics = cameraManager.getCameraCharacteristics(cameraId);
        StreamConfigurationMap map = cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        availableSizes = map.getOutputSizes(SurfaceTexture.class);
    }

    Size setPreferredSize(int width, int height, float zoomedAreaProportion) {
        this.zoomedAreaProportion = zoomedAreaProportion;
        int pixels = width * height;
        int candidateIndex = 0;
        int candidatePixels = 0;
        for (int i = 0; i < availableSizes.length; i++) {
            Size s = availableSizes[i];
            int product = s.getWidth() * s.getHeight();
            if (pixels == product) {
                preferredSize = s;

                zoomedSize = new Size((int) (preferredSize.getWidth() * zoomedAreaProportion),
                        (int) (preferredSize.getHeight() * zoomedAreaProportion));

                Log.i("TAG", "PreferredSize: " + preferredSize);
                Log.i("TAG", "ZoomedSize: " + zoomedSize);

                return preferredSize;
            } else if (pixels > product && product > candidatePixels) {
                candidateIndex = i;
                candidatePixels = product;
            }
        }
        return availableSizes[candidateIndex];
    }

    @SuppressLint("MissingPermission")
    void startCapture(List<Surface> surfaces) throws CameraAccessException {
        targetSurfaces = surfaces;

        HandlerThread thread = new HandlerThread("CameraOpen");
        thread.start();
        Handler openHandler = new Handler(thread.getLooper());
        cameraManager.openCamera(cameraId, mStateCallback, openHandler);
    }

    void closeCamera() {
        canTakePhoto = false;
        stopBackgroundThread();
        try {
            if (null != cameraDevice) {
                cameraDevice.close();
                cameraDevice = null;
            }
        } catch (IllegalStateException ie) {
            ie.printStackTrace();
        }
    }

    void focusUp() {
        if (cameraState == CameraState.PHOTO) {
            focusDistance += 0.025f;
            previewBuilder.set(CaptureRequest.LENS_FOCUS_DISTANCE, calculateFocusDistance());
            updatePreview();
            AppUtils.showToast(gvrContext, activity.getString(R.string.focus, String.format("%.03f", focusDistance)), 1);
        }
    }

    void focusDown() {
        if (cameraState == CameraState.PHOTO && focusDistance > 0) {
            focusDistance -= 0.025f;
            previewBuilder.set(CaptureRequest.LENS_FOCUS_DISTANCE, calculateFocusDistance());
            updatePreview();
            AppUtils.showToast(gvrContext, activity.getString(R.string.focus, String.format("%.03f", focusDistance)), 1);
        }
    }

    void takePicture() {

        if (!canTakePhoto || cameraState != CameraState.PHOTO) {
            return;
        }

        if (null == cameraDevice) {
            Log.e(TAG, "cameraDevice is null");
            return;
        }
        try {
            canTakePhoto = false;

            int width = CAPTURE_PHOTO_WIDTH;
            int height = CAPTURE_PHOTO_HEIGHT;

            ImageReader reader = ImageReader.newInstance(width, height, ImageFormat.JPEG, 1);
            List<Surface> outputSurfaces = new ArrayList<>(2);
            outputSurfaces.add(reader.getSurface());
            outputSurfaces.addAll(targetSurfaces);
            final CaptureRequest.Builder captureBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(reader.getSurface());
            captureBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);

            // Orientation
            int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
            captureBuilder.set(CaptureRequest.JPEG_ORIENTATION, ORIENTATIONS.get(rotation));

            final int finalWidth = width;
            final int finalHeight = height;

            ImageReader.OnImageAvailableListener readerListener = new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    Image image = null;
                    try {
                        image = reader.acquireLatestImage();
                        ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                        byte[] bytes = new byte[buffer.capacity()];
                        buffer.get(bytes);

                        int centerX = (int) (finalWidth / 2f) - (int) (finalWidth * zoomedAreaProportion / 2f);
                        int centerY = (int) (finalHeight / 2f) - (int) (finalHeight * zoomedAreaProportion / 2f);

                        Bitmap srcBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        Bitmap dstBmp = Bitmap.createBitmap(
                                srcBitmap,
                                centerX,
                                centerY,
                                (int) (finalWidth * zoomedAreaProportion),
                                (int) (finalHeight * zoomedAreaProportion)
                        );

                        if (listener != null) {
                            listener.onPhotoCaptured(dstBmp);
                        }
                    } finally {
                        if (image != null) {
                            image.close();
                        }
                    }
                }
            };
            reader.setOnImageAvailableListener(readerListener, backgroundHandler);
            final CameraCaptureSession.CaptureCallback captureListener = new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                    super.onCaptureCompleted(session, request, result);
                }
            };
            cameraDevice.createCaptureSession(outputSurfaces, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession session) {
                    try {
                        session.capture(captureBuilder.build(), captureListener, backgroundHandler);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession session) {
                }
            }, backgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    void setCameraState(CameraState cameraState) {
        this.cameraState = cameraState;
        updateCameraState();
    }

    private void updateCameraState() {
        switch (cameraState) {
            case QR_DECODING:
                startQrDecoding();
                break;
            case PHOTO:
                startPhotoPreview();
                break;
            case PREVIEW:
                startJustPreview();
                break;
        }
    }

    private void startPhotoPreview() {
        try {
            previewBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);

            previewBuilder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF);
            MeteringRectangle meteringRectangle = new MeteringRectangle(
                    (int) (preferredSize.getWidth() / 2f),
                    (int) (preferredSize.getHeight() / 2f),
                    zoomedSize.getWidth(),
                    zoomedSize.getHeight(),
                    MeteringRectangle.METERING_WEIGHT_MAX - 1
            );
            previewBuilder.set(CaptureRequest.CONTROL_AF_REGIONS, new MeteringRectangle[]{meteringRectangle});
            previewBuilder.set(CaptureRequest.LENS_FOCUS_DISTANCE, calculateFocusDistance());


            for (Surface s : targetSurfaces) {
                previewBuilder.addTarget(s);
            }

            cameraDevice.createCaptureSession(targetSurfaces, mCaptureCallback, backgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void updatePreview() {
        previewBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);

        startBackgroundThread();

        try {
            previewSession.setRepeatingRequest(previewBuilder.build(), null, backgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("Camera Background");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    private void stopBackgroundThread() {

        try {
            if (backgroundThread != null) {
                backgroundThread.quitSafely();
                backgroundThread.join();
            }
            backgroundThread = null;
            backgroundHandler = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private float calculateFocusDistance() {
        float minLens = cameraCharacteristics.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
        return focusDistance * minLens;
    }

    private float calculateFocusDistanceForScanningBarcode() {
        float minLens = cameraCharacteristics.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
        return FOCUS_DISTANCE_FOR_SCANNING_BAR_CODE * minLens;
    }

    //QR DECODER

    private final CameraCaptureSession.CaptureCallback mDecoderCaptureCallback = new CameraCaptureSession.CaptureCallback() {
        private void process(CaptureResult result) {
        }

        @Override
        public void onCaptureProgressed(CameraCaptureSession session, CaptureRequest request,
                                        CaptureResult partialResult) {
            process(partialResult);
        }

        @Override
        public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request,
                                       TotalCaptureResult result) {
            process(result);
        }

    };

    private final ImageReader.OnImageAvailableListener mOnImageAvailableListener =
            new ImageReader.OnImageAvailableListener() {

                @Override
                public void onImageAvailable(ImageReader reader) {
                    Image img = null;
                    img = reader.acquireLatestImage();
                    Result rawResult = null;
                    try {
                        if (img == null) throw new NullPointerException("cannot be null");
                        ByteBuffer buffer = img.getPlanes()[0].getBuffer();
                        byte[] data = new byte[buffer.remaining()];
                        buffer.get(data);
                        int width = img.getWidth();
                        int height = img.getHeight();

                        int centerX = (int) (width / 2f) - (int) (barCodeImageCroppedWidth / 2f);
                        int centerY = (int) (height / 2f) - (int) (barCodeImageCroppedHeight / 2f);

                        PlanarYUVLuminanceSource source = new PlanarYUVLuminanceSource(data,
                                width, height, centerX, centerY,
                                barCodeImageCroppedWidth, barCodeImageCroppedHeight,
                                false);

                        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));


                        rawResult = mQrReader.decode(bitmap);
                        onQRCodeRead(rawResult.getText());
                    } catch (ReaderException ignored) {
                        /* Ignored */
                    } catch (NullPointerException ex) {
                        ex.printStackTrace();
                    } finally {
                        mQrReader.reset();
                        if (img != null)
                            img.close();

                    }
                }

            };

    private void startQrDecoding() {
        startBackgroundThread();
        readyToReadQr = true;

        if (mQrReader == null) {
            mQrReader = new UPCAReader();
        }

        if (mImageReader == null) {
            mImageReader = ImageReader.newInstance(barCodeImageFullWidth, barCodeImageFullHeight, IMAGE_FORMAT, 2);
            mImageReader.setOnImageAvailableListener(mOnImageAvailableListener, backgroundHandler);
        }

        try {

            Surface mImageSurface = mImageReader.getSurface();
            final CaptureRequest.Builder decoderRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            List<Surface> outputSurfaces = new ArrayList<>(2);
            for (int i = 0; i < targetSurfaces.size(); i++) {
                outputSurfaces.add(targetSurfaces.get(i));
                decoderRequestBuilder.addTarget(targetSurfaces.get(i));
            }
            decoderRequestBuilder.addTarget(mImageSurface);
            outputSurfaces.add(mImageSurface);

            // Here, we create a CameraCaptureSession for camera preview.
            cameraDevice.createCaptureSession(outputSurfaces,
                    new CameraCaptureSession.StateCallback() {

                        @Override
                        public void onConfigured(CameraCaptureSession cameraCaptureSession) {
                            // The camera is already closed
                            if (cameraDevice == null) return;

                            previewSession = cameraCaptureSession;
                            try {
                                int centerX = (int) (barCodeImageFullWidth / 2f) - (int) (barCodeImageCroppedWidth / 2f);
                                int centerY = (int) (barCodeImageFullHeight / 2f) - (int) (barCodeImageCroppedHeight / 2f);

                                MeteringRectangle meteringRectangle = new MeteringRectangle(
                                        centerX, centerY,
                                        barCodeImageCroppedWidth, barCodeImageCroppedHeight,
                                        MeteringRectangle.METERING_WEIGHT_MAX - 1
                                );

                                decoderRequestBuilder.set(CONTROL_AF_MODE, CONTROL_AF_MODE_OFF);
                                decoderRequestBuilder.set(CaptureRequest.LENS_FOCUS_DISTANCE, calculateFocusDistanceForScanningBarcode());
                                decoderRequestBuilder.set(CaptureRequest.CONTROL_AF_REGIONS, new MeteringRectangle[]{meteringRectangle});


                                CaptureRequest mPreviewRequest = decoderRequestBuilder.build();
                                previewSession.setRepeatingRequest(mPreviewRequest, mDecoderCaptureCallback,
                                        backgroundHandler);
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
                        }
                    }, backgroundHandler
            );
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void onQRCodeRead(final String text) {
        if (readyToReadQr) {
            readyToReadQr = false;
            listener.onQrCodeRead(text);
        }
    }

    //JUST PREVIEW

    private void startJustPreview() {
        try {
            startBackgroundThread();

            final CaptureRequest.Builder decoderRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            List<Surface> outputSurfaces = new ArrayList<>(2);
            for (int i = 0; i < targetSurfaces.size(); i++) {
                outputSurfaces.add(targetSurfaces.get(i));
                decoderRequestBuilder.addTarget(targetSurfaces.get(i));
            }

            cameraDevice.createCaptureSession(outputSurfaces,
                    new CameraCaptureSession.StateCallback() {

                        @Override
                        public void onConfigured(CameraCaptureSession cameraCaptureSession) {
                            if (cameraDevice == null) return;

                            previewSession = cameraCaptureSession;
                            try {
                                decoderRequestBuilder.set(CONTROL_AF_MODE, CONTROL_AF_STATE_ACTIVE_SCAN);
                                CaptureRequest mPreviewRequest = decoderRequestBuilder.build();
                                previewSession.setRepeatingRequest(mPreviewRequest, null, backgroundHandler);
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
                        }
                    }, backgroundHandler
            );
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    interface CameraListener {
        void onQrCodeRead(String text);

        void onPhotoCaptured(Bitmap capturedPhoto);
    }
}
