package com.trachoma.vr.menu;
/*
 * Created by Anton Bevza on 1/16/18.
 */

import com.trachoma.vr.R;
import com.trachoma.vr.focus.FocusListener;
import com.trachoma.vr.focus.FocusableSceneObject;

import org.gearvrf.GVRAndroidResource;
import org.gearvrf.GVRContext;
import org.gearvrf.GVRDrawFrameListener;
import org.gearvrf.GVRMaterial;
import org.gearvrf.GVRMesh;
import org.gearvrf.GVRMeshCollider;
import org.gearvrf.GVRRenderData;
import org.gearvrf.GVRSceneObject;
import org.gearvrf.GVRTexture;

public class CancelButton extends FocusableSceneObject implements FocusListener {

    private static final float LOADING_SPEED = 0.015f;
    private float itemWidth = 0.5f;
    private float itemHeight = 0.5f;
    private GVRSceneObject loadComponent = null;
    private LoadComponentListener listener;
    private GVRDrawFrameListener drawFrameListener;
    private float valueFloatTexture;

    public CancelButton(GVRContext gvrContext) {
        super(gvrContext);
        attachRenderData(new GVRRenderData(gvrContext));
        getRenderData().setMaterial(new GVRMaterial(gvrContext));
        getRenderData().setMesh(gvrContext.createQuad(itemWidth, itemHeight));
        GVRTexture texture = gvrContext.getAssetLoader().loadTexture(new GVRAndroidResource(gvrContext, R.drawable.ic_red));
        getRenderData().getMaterial().setMainTexture(texture);

        this.attachCollider(new GVRMeshCollider(getGVRContext(), false));
        this.focusListener = this;
    }

    @Override
    public void gainedFocus(FocusableSceneObject object) {
        createLoadComponent();
    }

    @Override
    public void lostFocus(FocusableSceneObject object) {
        if (this.loadComponent != null) {
            stopLoading();
        }
    }

    @Override
    public void inFocus(FocusableSceneObject object) {

    }

    private void createLoadComponent() {
        GVRMesh quad = getGVRContext().createQuad(itemWidth, itemHeight);
        GVRTexture texture = getGVRContext().getAssetLoader().loadTexture(new GVRAndroidResource(getGVRContext(), R.drawable.ic_green));
        loadComponent = new GVRSceneObject(getGVRContext(), quad, texture);
        loadComponent.getTransform().setPosition(0, 0, 0.01f);
        loadComponent.getTransform().setScale(0, 0, 1);

        drawFrameListener = new GVRDrawFrameListener() {

            @Override
            public void onDrawFrame(float frameTime) {
                valueFloatTexture += LOADING_SPEED;

                if (valueFloatTexture <= 1) {
                    loadComponent.getTransform().setScale(valueFloatTexture, valueFloatTexture, 1);

                } else {
                    stopLoading();
                    listener.onFinishLoadComponent();
                }

            }
        };

        getGVRContext().registerDrawFrameListener(drawFrameListener);
        addChildObject(loadComponent);
    }

    private void stopLoading() {
        getGVRContext().unregisterDrawFrameListener(drawFrameListener);
        valueFloatTexture = 0.0f;
        removeChildObject(loadComponent);
    }

    public void setListener(LoadComponentListener listener) {
        this.listener = listener;
    }
}
