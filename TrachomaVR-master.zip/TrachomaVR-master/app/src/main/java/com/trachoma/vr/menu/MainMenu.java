package com.trachoma.vr.menu;
/*
 * Created by Anton Bevza on 1/18/18.
 */

import android.graphics.Color;

import com.trachoma.vr.R;

import org.gearvrf.GVRAndroidResource;
import org.gearvrf.GVRContext;
import org.gearvrf.GVRMaterial;
import org.gearvrf.GVRRenderData;
import org.gearvrf.GVRSceneObject;
import org.gearvrf.GVRTexture;

public class MainMenu extends GVRSceneObject {
    private Listener listener;

    public MainMenu(GVRContext gvrContext) {
        super(gvrContext);

        attachRenderData(new GVRRenderData(gvrContext));
        getRenderData().setMaterial(new GVRMaterial(gvrContext));
        getRenderData().setMesh(gvrContext.createQuad(3, 2));
        GVRTexture texture = gvrContext.getAssetLoader().loadTexture(new GVRAndroidResource(gvrContext, R.drawable.white));
        getRenderData().getMaterial().setMainTexture(texture);
        getRenderData().getMaterial().setColor(Color.WHITE);

        final MenuButton scanBarcodeButton = new MenuButton(getGVRContext(), getGVRContext().getActivity().getString(R.string.scan_barcode));
        scanBarcodeButton.getTransform().setPosition(0f, 0, 0.01f);
        scanBarcodeButton.setListener(new LoadComponentListener() {
            @Override
            public void onFinishLoadComponent() {
                if (listener != null) {
                    listener.onScanBarcodeSelected();
                }
            }
        });

        addChildObject(scanBarcodeButton);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public interface Listener {
        void onScanBarcodeSelected();
    }

}
