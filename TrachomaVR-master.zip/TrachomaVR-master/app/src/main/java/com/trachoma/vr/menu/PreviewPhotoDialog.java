package com.trachoma.vr.menu;
/*
 * Created by Anton Bevza on 1/29/18.
 */

import android.graphics.Bitmap;
import android.graphics.Color;

import com.trachoma.vr.R;

import org.gearvrf.GVRAndroidResource;
import org.gearvrf.GVRBitmapImage;
import org.gearvrf.GVRContext;
import org.gearvrf.GVRMaterial;
import org.gearvrf.GVRMesh;
import org.gearvrf.GVRRenderData;
import org.gearvrf.GVRSceneObject;
import org.gearvrf.GVRTexture;

public class PreviewPhotoDialog extends GVRSceneObject {
    private Listener listener;

    public PreviewPhotoDialog(GVRContext gvrContext, Bitmap bitmap) {
        super(gvrContext);

        GVRMesh mesh = gvrContext.createQuad(4f, 2.25f);
        GVRTexture tex = new GVRTexture(gvrContext);
        tex.setImage(new GVRBitmapImage(gvrContext, bitmap));
        GVRSceneObject imageObject = new GVRSceneObject(gvrContext, mesh, tex);
        imageObject.getTransform().setPosition(0, 0.5f, 0.01f);

        addChildObject(imageObject);

        attachRenderData(new GVRRenderData(gvrContext));
        getRenderData().setMaterial(new GVRMaterial(gvrContext));
        float width = 4.5f;
        float height = 3.5f;
        getRenderData().setMesh(gvrContext.createQuad(width, height));

        GVRTexture texture = gvrContext.getAssetLoader().loadTexture(new GVRAndroidResource(gvrContext, R.drawable.white));
        getRenderData().getMaterial().setMainTexture(texture);
        getRenderData().getMaterial().setColor(Color.WHITE);
        final MenuButton saveButton = new MenuButton(getGVRContext(), gvrContext.getActivity().getString(R.string.save));
        saveButton.getTransform().setPosition(-1f, -1.25f, 0.01f);
        saveButton.setListener(new LoadComponentListener() {
            @Override
            public void onFinishLoadComponent() {
                if (listener != null) {
                    listener.onPositiveButtonClicked();
                }
            }
        });

        addChildObject(saveButton);

        final MenuButton deleteButton = new MenuButton(getGVRContext(), gvrContext.getActivity().getString(R.string.delete));
        deleteButton.getTransform().setPosition(1f, -1.25f, 0.01f);
        deleteButton.setListener(new LoadComponentListener() {
            @Override
            public void onFinishLoadComponent() {
                if (listener != null) {
                    listener.onNegativeButtonClicked();
                }
            }
        });

        addChildObject(deleteButton);

        CancelButton cancelButton = new CancelButton(getGVRContext());
        cancelButton.getTransform().setPosition(width / 2f, height / 2f, 0.01f);
        cancelButton.setListener(new LoadComponentListener() {
            @Override
            public void onFinishLoadComponent() {
                if (listener != null) {
                    listener.onCancelButtonClicked();
                }
            }
        });
        addChildObject(cancelButton);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public interface Listener {
        void onPositiveButtonClicked();

        void onNegativeButtonClicked();

        void onCancelButtonClicked();
    }


}
